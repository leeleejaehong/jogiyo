package com.itbank.jogiyo.dto;

public class CouponDTO {
	private int couponid;
	private String couname;
	private String coucontent;
	private int storeid;
	public int getCouponid() {
		return couponid;
	}
	public void setCouponid(int couponid) {
		this.couponid = couponid;
	}
	public String getCouname() {
		return couname;
	}
	public void setCouname(String couname) {
		this.couname = couname;
	}
	public String getCoucontent() {
		return coucontent;
	}
	public void setCoucontent(String coucontent) {
		this.coucontent = coucontent;
	}
	public int getStoreid() {
		return storeid;
	}
	public void setStoreid(int storeid) {
		this.storeid = storeid;
	}
	
	

}