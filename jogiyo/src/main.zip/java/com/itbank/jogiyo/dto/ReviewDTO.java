package com.itbank.jogiyo.dto;

public class ReviewDTO {

}
