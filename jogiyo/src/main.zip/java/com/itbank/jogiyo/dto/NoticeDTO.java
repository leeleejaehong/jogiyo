package com.itbank.jogiyo.dto;

public class NoticeDTO {
	private int notiid;
	private String subject;
	private String content;
	private String indate;
	public int getNotiid() {
		return notiid;
	}
	public void setNotiid(int notiid) {
		this.notiid = notiid;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getIndate() {
		return indate;
	}
	public void setIndate(String indate) {
		this.indate = indate;
	}
	
	
}
