package com.itbank.jogiyo.dto;

public class JstoreCateDTO {
	private int jscateid;
	private int storeid;
	private String jstorename;
	public int getJscateid() {
		return jscateid;
	}
	public void setJscateid(int jscateid) {
		this.jscateid = jscateid;
	}
	public int getStoreid() {
		return storeid;
	}
	public void setStoreid(int storeid) {
		this.storeid = storeid;
	}
	public String getJstorename() {
		return jstorename;
	}
	public void setJstorename(String jstorename) {
		this.jstorename = jstorename;
	}

}
